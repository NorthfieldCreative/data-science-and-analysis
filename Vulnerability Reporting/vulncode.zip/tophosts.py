################################################################################################
####                                                                                        ####
####            ##############################################################              ####
####            ##                                                          ##              ####
####            ##      A module to return the top 10 vulnerable IPs        ##              ####
####            ##      by count of vulnerabilities for the current month.  ##              ####
####            ##      This module will return results in a stacked bar    ##              ####
####            ##      chart                                               ##              ####
####            ##                                                          ##              ####
####            ##############################################################              ####
####                                                                                        ####
################################################################################################

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
from tkinter import CENTER, N
def top10hosts(convertedmonth,year,sqladbconn):
    # Try to open the file
    #inputmonth=convertedmonth + '.csv'
    monthname=convertedmonth
    
    hosts=[]
    
    query="SELECT * FROM "+convertedmonth.lower()+"_"+str(year)
    monthtocount=pd.read_sql(query, sqladbconn)


    for host in monthtocount['IP Address'].value_counts().nlargest(10).index:
        hosts.append(host)
    tophosts={monthname: hosts}
    return tophosts
