################################################################################################
####                                                                                        ####
####            ##############################################################              ####
####            ##                                                          ##              ####
####            ##      This module tracks vulnerability remediations       ##              ####
####            ##      by comparing current and previous vulnerability     ##              ####
####            ##      "titles" for each IP in the scan results            ##              ####
####            ##                                                          ##              ####
####            ##                                                          ##              ####
####            ##############################################################              ####
####                                                                                        ####
################################################################################################




def remediations(month,lmonth):


# Try to open the file
    thismonthfile=month + '.csv'
    lastmonthfile=lmonth + '.csv'

    try:
        thismonthdf = pd.read_csv(thismonthfile,  low_memory=False)
    except:
        print("While attempting to load this months data to analyze remediations, we expected to find ", thismonth + '.csv', "in the current working directory (", os.getcwd(), "), but failed. Quitting!")
        exit()

    try:
        lastmonthdf = pd.read_csv(lastmonthfile,  low_memory=False)
    except:
        print("While attempting to load this months data to analyze remediations, we expected to find ", thismonth + '.csv', "in the current working directory (", os.getcwd(), "), but failed. Quitting!")
        exit()

    #Combining IPs with vulnerability titles into one column for easy comparison
    lastmonthdf['combined']=lastmonthdf['IP Address'] + lastmonthdf['Title']
    thismonthdf['combined']=thismonthdf['IP Address'] + thismonthdf['Title']


    #searching for vulnerabilities that have not been remediated since at least last month's scan. 
    #By using the concatenated (combined columns) data of IP Address and Title, this is being determined
    #by looking at this months and last months data; where an IP Address and Title match between both
    #datasets, it is logically assumed that the vulnerability has not been remediated and persists. 


    rresults=thismonthdf[thismonthdf['combined'].str.contains('|'.join(lastmonthdf['combined']))]
    #Searching for vulnerabilities that have been remediated. This is determined by performing 
    #the opposite query as above. In other words, we're searching this months IP addresses and titles
    #and returning all rows that do NOT match last months data. In this way, we are logically assuming 
    #that a vulnerability has been remediated. Please note that this ONLY considers vulnerability scan results
    #and certain other factors (like a server getting decommissioned) could effect the results. In the future
    #it may be possible to check server status with a ping to reconcile this potential discrepancy.
    dresults=thismonthdf[~thismonthdf['combined'].str.contains('|'.join(lastmonthdf['combined']))]
    #totaldifferancecount = thismonthdf[thismonthdf['IP Address'].str.contains('|'.join(lastmonthsips))]
    print(rresults['combined'])
    print(dresults['combined'])

###############concatenate these two rows and compare that way??
    #print(results['combined'])
    #overallchange=len(lastmonthsips.index)-len(results.index)
    #print(len(results.index))
    #print(len(lastmonthsips.index))
    #print('There was an overall difference overallchange)

#remediations(getmonth(rawmonth),getmonth(rawmonth-1))


