################################################################################################
####                                                                                        ####
####            ##############################################################              ####
####            ##                                                          ##              ####
####            ##      This function takes the current top 10 IPs and      ##              ####
####            ##      creates a table and populates it with the top 10    ##              ####
####            ##      IPs along its respective hostname, internal IP, OS  ##              ####
####            ##      protocol(s), port(s), and service name(s)           ##              ####
####            ##                                                          ##              ####
####            ##      Inventory.csv is the list of external hosts along   ##              ####
####            ##      with their respective host names and internal IPs   ##              ####
####            ##                                                          ##              ####
####            ##############################################################              ####
####                                                                                        ####
################################################################################################
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
from tkinter import CENTER, N
import getmonth
import tophosts
def inventorytable(sqladbconn,continuewithold,year,rawmonth):

    
    query="SELECT * FROM external_resource_inventory"
    inventory=pd.read_sql(query, sqladbconn)
    '''
    try:
        inventory = pd.read_csv('inventory.csv',  low_memory=False) 
    except:
        print("inventory file not foud for this month. Expected to find inventory.csv in the current working directory (", os.getcwd(), "), but failed.")
        exit()
    '''
    #Gets the name of the current month, passes it to the top 10 hosts function, which
    #returns the current top 10 in the form of a dictionary. Then, a pandas dataframe
    #is created from that dictionary


    if continuewithold=="y":
        currenttop10=pd.DataFrame.from_dict(tophosts.top10hosts(getmonth.getmonth(rawmonth-1),year,sqladbconn))
    else:
        currenttop10=pd.DataFrame.from_dict(tophosts.top10hosts(getmonth.getmonth(rawmonth-1),year,sqladbconn))

    
    
    
    finaltable=inventory[inventory['IP Address'].str.contains('|'.join(currenttop10.iloc[:,0]))]
    #print(currenttop10.iloc[:,0].values)
    #searchfor = cisalist['cveID']
    
    #results = wholemonth[wholemonth['CVE'].str.contains('|'.join(searchfor))]
    #print(currenttop10)
    #def listingtop10():
    #    for ip1 in currenttop10.iloc[:,0]:
    #        return ip1
    #for ip2 in inventory['IP Address']:
    finaltable.fillna('Unkown', inplace=True)
    #print(finaltable)   
        


    #preparing a table to present the data
    fig, ax = plt.subplots()
    # hide axes
    fig.patch.set_visible(False)
    ax.axis('off')
    ax.axis('tight')
    #assigning data to the matplotlib table
    #tb =ax.table(cellText=finaltable.values, colLabels=finaltable.columns,loc='center')
    
    #ax.table(cellText=finaltable.values, colLabels=finaltable.columns,loc='center')
    
    #tb.set_fontsize(100)
    
    #plt.text(-0.1, 0, finaltable.to_string(index=False, justify=CENTER), fontsize = 8)
    plt.text(-0.125, 0, '  A CSV file named "top 10 ips with attributes.csv" has been saved to the local working directory this script was executed from.\n\n It contains the top 10 most vulnerable IPs found this month along with (where the respective information is available) their \n\n hostname, internal IP, OS, effected protocol, effected port, and service name. \n\n Additional rows exist for each IP to breaking them down via these attributes where appropriate.', fontsize = 12)
    #plt.title('font', size=2)
    #fig.set_size_inches(500,500, forward=True)
    fig.tight_layout()
    plt.show()
    finaltable.to_csv(r'top 10 ips with attributes.csv', index = False)
    #print(finaltable)
