
##############################################################
##                                                          ##
##      This function compares discovered CVEs with         ##
##      CISA's list of CVEs that are known to be            ##
##      Exploited in the wild                               ##
##                                                          ##
##############################################################

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
from tkinter import CENTER, N
def exploitedinthewild(month,year,sqladbconn):


# loading the CISA list and assigning the CVE column to a variable that can be searched
    try:
        cisalist = pd.read_csv('https://www.cisa.gov/sites/default/files/csv/known_exploited_vulnerabilities.csv', low_memory=False) 
        searchfor = cisalist['cveID']
    except:
        print("Couldn't load the list of known exploited vulnerabilities from CISA! Quitting!")
        exit()


    query="SELECT * FROM "+month.lower()+"_"+str(year)
    wholemonth=pd.read_sql(query, sqladbconn)
# dropping machines without a CVE from the table so the data can be parsed
    wholemonth.dropna(subset=['CVE'], inplace=True)
#############################################
# comparing the list of known exploitable CVEs to the
# list available from Pondurance and assigning it
# to another variable for further processing
##############################################

    results = wholemonth[wholemonth['CVE'].str.contains('|'.join(searchfor))]


    allcvecount=len(wholemonth.index)
    resultscount = len(results.index)
    #print("Total CVE's foud in our environment: ", allcvecount)
    #print("Of these, count of CVEs known to be exploited: ", resultscount)
    #print(results[['IP Address','CVE']])
    #return vulncount

    sources=['Total Discovered CVEs: ' + str(allcvecount), 'CVEs identified by CISA as being actively exploited: ' + str(resultscount)]
    data=[allcvecount,resultscount]
    plt.pie(data, labels=sources, autopct='%1.1f%%')
    plt.title('Actively exploited CVEs found in our environment for ' + month)
    #plt.text(-3.1, 0.1, 'Sine wave', fontsize = 23)
    plt.text(2.1, 1, 'List of CVEs found in our environment\nknown to be actively exploited in the wild:\n\n' + results[['IP Address','CVE']].to_string(index=False, justify=CENTER), fontsize = 12)
    #print(results[['IP Address','CVE']].to_string(index=False, justify=CENTER))
    plt.show()









