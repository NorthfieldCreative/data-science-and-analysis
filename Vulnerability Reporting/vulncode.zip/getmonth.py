def getmonth(number):
    if number == 1:
        currentmonth="January"
    elif number==2:
        currentmonth="February"
    elif number==3:
        currentmonth="March"
    elif number==4:
        currentmonth="April"
    elif number==5:
        currentmonth="May"
    elif number==6:
        currentmonth="June"
    elif number==7:
        currentmonth="July"
    elif number==8:
        currentmonth="August"
    elif number==9:
        currentmonth="September"
    elif number==10:
        currentmonth="October"
    elif number==11:
        currentmonth="November"
    elif number==12:
        currentmonth="December"
    return currentmonth