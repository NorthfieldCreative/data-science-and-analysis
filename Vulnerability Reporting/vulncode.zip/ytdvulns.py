
##############################################################
##                                                          ##
##      This module aggregates YTD vulnerabilities          ##
##      and presents them on a line chart by month          ##
##                                                          ##
##############################################################
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
def ytdvulnsbymonth(year,mycursor):
    vulncounts=[]
    monthforvulncount=[]
    '''
    for i in range(rawmonth + 1):
        if i != 0:
            vulncounts.append(vulncounter(getmonth(i)))
            monthforvulncount.append(getmonth(i))
    '''
    #getting all of the tables for this year
    mycursor.execute("SHOW TABLES LIKE '%"+str(year)+"'")
    #adding the available months to a list for later processing
    for x in mycursor:
        monthforvulncount.append(x[0])
    #counting the number of vulnerabilities from each month
    #and adding it to a list for later processing
    for monthsytd in monthforvulncount:
        mycursor.execute("SELECT COUNT(*) FROM "+monthsytd)
        tempcount=mycursor.fetchone()
        vulncounts.append(tempcount[0])

    
    #Compiling each list into a dictionary for further processing
    mvtracker={'Month':monthforvulncount, 'Vulnerabilities discovered':vulncounts}


    #converting to dataframe for actual processing
    monthlyvulntracker=pd.DataFrame.from_dict(mvtracker)
    
    #adding a column and assigning month numbers to sort
    monthlyvulntracker['monthnumber']=monthlyvulntracker['Month'].map(lambda x: 1 if "january" in x else 2 if "february" in x else 3 if "march" in x else 4 if "april" in x else 5 if "may" in x else 6 if "june" in x else 7 if "july" in x else 8 if "august" in x else 9 if "september" in x else 10 if "october" in x else 11 if "november" in x else 12 if "december" in x else "")
    #sorting the dataframe
    monthlyvulntracker=monthlyvulntracker.sort_values(by=['monthnumber'], ascending=True)
    #dropping the extra column
    monthlyvulntracker=monthlyvulntracker.drop('monthnumber', axis=1)
    
    
    
    
    
    plt.plot(monthlyvulntracker["Month"], monthlyvulntracker["Vulnerabilities discovered"])



    plt.title("Count of vulnerabilities by month")
    for x, y in zip(monthlyvulntracker["Month"], monthlyvulntracker["Vulnerabilities discovered"]):
        label = y
        plt.annotate(label, (x, y),xycoords="data",textcoords="offset points",xytext=(0, 10), ha="center")
    plt.show()