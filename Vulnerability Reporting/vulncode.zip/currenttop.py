import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
from tkinter import CENTER, N


def currenttopipsandseveritychart(thismonth, dbconnection, year):
    
    # Original version, trying to open the file
    '''
    try:
        xl=pd.ExcelFile('Shure_External_' + thismonth + '_2022.xlsx')
        restring='.*' + thismonth + '.*External\sVulns'
        regex=re.compile(restring)
        sheets=[n for n in xl.sheet_names if regex.match(n)]
        truesheet="".join(sheets)
        #currentmonthrawdata = pd.read_csv(thismonth + '.csv',  low_memory=False)
        currentmonthrawdata = pd.read_excel (xl, sheet_name=truesheet, skiprows=1)
    except:
        print("Data file not foud for this month. Expected to find Shure_External_" + thismonth + '_2022.xlsx', "in the current working directory (", os.getcwd(), "), but failed.")
        exit()
    
    '''
    query="SELECT * FROM "+thismonth.lower()+"_"+str(year)
    currentmonthrawdata=pd.read_sql(query, dbconnection)
    print(currentmonthrawdata)
    #exit()
    # Identifying the top 10 hosts by counting findings
    topips=currentmonthrawdata['IP Address'].value_counts().nlargest(10)
    # Grouping severities to IPs to visualize
    atm=currentmonthrawdata.groupby(['IP Address', 'Severity']).size().unstack()


    #Creating lists to populate with the respective attribute
    #These lists will later be compiled into a dataframe
    #The dataframe will then be used to created stacked bar chart
    ipaddresses=[]
    critical=[]
    high=[]
    low=[]
    none=[]

    #for each ip in the grouped data, compare that to the original CSV
    for ip1 in atm.index:

        for ip2 in topips.index:

            #If IPs match, then it is a top 10 IP
            #we will populate the severity lists
            #so that we can later visualize them
            if ip1==ip2:
                ipaddresses.append(ip1)
                critical.append(atm.loc[ip1, 'Critical'])
                high.append(atm.loc[ip1, 'High'])
                low.append(atm.loc[ip1, 'Low'])
                none.append(atm.loc[ip1, 'None'])

    #Compiling each list into a dictionary
    topaugustipswithseverities={'IP Address':ipaddresses, 'Critical':critical, 'High':high, 'Low':low, 'None':none}
    #converting the dictionary to a dataframe
    augusttop=pd.DataFrame.from_dict(topaugustipswithseverities)
    #print(topips)


    #replacing NaN with 0
    augusttop = augusttop.fillna(0)

    #adding the rows to get a sum to be sorted
    augusttop["total"] = augusttop.sum(axis=1)
    augusttop = augusttop.sort_values(by=['total'], ascending=True)

    #Removing the place holder total column for visualization
    augusttop = augusttop.drop('total', axis=1)

    critical="red"
    high="brown"
    low="orange"
    none="grey"

    colors=[critical, high, low, none]
    
    #defining a horizontal stacked bar chart
    ax=augusttop.plot(kind='barh', stacked=True, color=colors)
    #assigning IP addresses to the y-axis ticks
    ax.set_yticklabels(ipaddresses)


    # Labeling the chart
    ax.set_title("Top 10 vulnerable IPs based on findings count for " + thismonth, fontsize=12)

 
    ##  This for loop displays and labels the counts for each respective stacked bar  ##
    for i in ax.patches:
        # get_width pulls left or right; get_y pushes up or down
        ax.text(i.get_width()+.1, i.get_y()+.31, \
                str(round((i.get_width()), 2)), fontsize=12, color='dimgrey')

    #Using the X axis label to display the dataframe as a table
    plt.xlabel(augusttop.to_string(index=False, justify=CENTER))

    #Using a logarithmic scale so that everything is easier to see
    plt.xscale("log")


    #making it look nicer
    plt.tight_layout()
    #showing the chart
    plt.show()


    #print(currentmonth)