##############################################################
##                                                          ##   
##      This module identifies and analyzes the top         ##
##      vulnerable hosts YTD that remain vulnerable         ##
##                                                          ##
##      YTD top consistently vulnerable hosts               ##
##############################################################
from numpy import char
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
from tkinter import CENTER, N
import getmonth
import tophosts
def consistenhosts(year,mycursor,sqladbconn,continuewithold,rawmonth):
    #creating temporary dataframes to process and analyze data
    tempdf2=pd.DataFrame()
    tempdf3=pd.DataFrame()
    tempdf4=pd.DataFrame()

    monthforvulncount=[]



    #getting all of the tables for this year
    mycursor.execute("SHOW TABLES LIKE '%"+str(year)+"'")
    #adding the available months to a list for later processing
    for x in mycursor:
        monthforvulncount.append(x[0])
    #counting the number of vulnerabilities from each month
    #and adding it to a list for later processing
    '''
    for monthsytd in monthforvulncount:
        mycursor.execute("SELECT COUNT(*) FROM "+monthsytd)
        tempcount=mycursor.fetchone()
        vulncounts.append(tempcount[0])
    '''
    #monthforvulncount=map(str.strip('2022'), monthforvulncount)
    m2=[]
    for item in monthforvulncount:
        if "_2022" in item:
            m2.append(item.strip("_2022"))
    for i in m2:
        #print(i)
        ##############################################Gets the top top vulnerable IPs for the currently iterated month
        tempdf=pd.DataFrame.from_dict(tophosts.top10hosts(i,year,sqladbconn))


        #Gets the top 10 vulnerable IPs for THIS month (or last.... as indicated)
        if continuewithold=="y":
            currentdf=pd.DataFrame.from_dict(tophosts.top10hosts(getmonth.getmonth(rawmonth-1),year,sqladbconn))
        else:
            currentdf=pd.DataFrame.from_dict(getmonth.getmonth(rawmonth-1),year,sqladbconn)

        #Compares the top vulnerable IPs in the current iterated month 
        #to the top IPs this month. Any matches found are assigned to the
        #results dataframe
        if continuewithold=="y":
            results= currentdf[currentdf[[getmonth.getmonth(rawmonth-1)]].astype(str).sum(axis = 1).isin(tempdf[[i]].astype(str).sum(axis = 1))]
        else:
            results= currentdf[currentdf[[getmonth.getmonth(rawmonth)]].astype(str).sum(axis = 1).isin(tempdf[[i]].astype(str).sum(axis = 1))]

        #Combining the results into "tempdf2" as we iterate through each month ytd
        tempdf2=pd.concat([tempdf2,results])



        #Combining the results into "tempdf2" as we iterate through each month ytd
        tempdf2=pd.concat([tempdf2,results])

        #to make sense of the data and to visualize it, we transpose the data into a
        #new dataframe with appropriately named columns
        tempdf3['ips']=results
        tempdf3['month']=i
        tempdf3['monthnumber']=i###########################################################33 ????????? this i could cause a problem

        #dropping blank rows that were automatically created
        #during the iterative process
        tempdf3=tempdf3[tempdf3['ips'].notna()]

        #combining all the data together so that it can be visualized
        tempdf4=pd.concat([tempdf4,tempdf3])
    #defining the attributes that we want to visualize
    chart=tempdf4.groupby(['ips', 'month']).size().unstack()


    #In the case where data isn't available for the whole year, 
    #this section adds a blank column to the dataframe. Once
    #every month is represented, we can then sort the columns
    #by month so that the data can be effectively visualized. 
    if not 'january' in chart.columns:
        chart['january']=""
    if not 'february' in chart.columns:
        chart['february']=""
    if not 'march' in chart.columns:
        chart['march']=""
    if not 'april' in chart.columns:
        chart['april']=""
    if not 'may' in chart.columns:
        chart['may']=""
    if not 'june' in chart.columns:
        chart['june']=""
    if not 'july' in chart.columns:
        chart['july']=""
    if not 'august' in chart.columns:
        chart['august']=""
    if not 'september' in chart.columns:
        chart['september']=""
    if not 'october' in chart.columns:
        chart['october']=""
    if not 'november' in chart.columns:
        chart['november']=""
    if not 'december' in chart.columns:
        chart['december']=""
    
    #sorting coloumns in chronological order. It's ok
    #if a given column is blank because it simply won't
    #be represented in the chart if there is no data
    #populated.
    chart=chart[['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december']]
    

    #Assigning color shades by month. This will form a green gradient
    january="#0f3d0f"
    february="#145214"
    march="#196619"
    april="#1f7a1f"
    may="#248f24"
    june="#29a329"
    july="#2eb82e"
    august="#33cc33"
    september="#47d147"
    october="#5cd65c"
    november="#70db70"
    december="#85e085"

    colors=[january,february,march,april,may,june,july,august,september,october,november,december]






    #defining the chart (barh = horizontal bar chart)
    chart.plot(kind='barh', stacked=True, color=colors)

    #naming and presenting the chart
    plt.title('The below addresses were in the top 10 vulnerable IPs during a previous month YTD, and are still in the top 10 IPs this month. \nThis stacked bar chart indicates which month YTD respective IPs were in the top 10. \nMonths are stacked to indicate how frequently this happens and to help prioritize.')
    plt.show()
